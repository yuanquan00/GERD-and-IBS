library(remotes)
library(TwoSampleMR)
library(data.table)
library(ieugwasr) 
setwd('I:\\GWAS数据\\GERDonIBS多变量')
IBS_dat <- as.data.frame(fread("finngen_R10_K11_IBS.gz", header = T)) #读取LDL文件
head(IBS_dat)
IBS_dat$`pval` <- as.numeric(IBS_dat$`pval`)#将p值转为数值型变量
IBS_dat <- IBS_dat[which(IBS_dat$`pval` < 5e-6),] #提取显著SNP用于后续clump
IBS_gwas <- IBS_dat[,c("rsids", "pval")] #选取rsid和p值这两列
colnames(IBS_gwas) <- c("rsid", "pval") #修改列名，列名必须为rsid和pval
head(IBS_gwas)

a <- ld_clump_local( dat = IBS_gwas, clump_kb = 10000, clump_r2 = 0.001, clump_p = 1, 
                     bfile = "I:/data_maf0.01_rs_ref/data_maf0.01_rs_ref", 
                     plink_bin = "I:/plink/plink_win64_20231211/plink.exe")
#这里需要注意bfile只需填plink文件的前缀 data_maf0.01_rs_ref即可
dim(a) #clump后只剩个17IV了
head(a)
#[1] 802
IBS_iv <- IBS_dat[which(IBS_dat$rsids%in%a$rsid), ] #返回源数据将clump后的IV信息提取出来
dim(IBS_iv) 
head(IBS_iv)
#[1] 80 10
IBS_iv<- format_data(
  dat=IBS_iv,
  type = "exposure",
  snps = IBS_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "rsids",
  beta_col = "beta",
  se_col = "sebeta",
  #eaf_col="effect_allele_frequency",
  effect_allele_col = "alt",
  other_allele_col = "ref",
  pval_col = "pval",
  chr_col = "#chrom",
  pos_col = "pos"
)
#write.csv(IBS_iv,"finngen_IBS_clumped.5e-6.csv")
GERD<-fread("GCST90000514_buildGRCh37GERD.tsv.gz")
head(GERD)
GERD <- data.frame(GERD)
GERD_outcome_data<- format_data(
  dat=GERD,
  type = "outcome",
  snps = IBS_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  eaf_col="effect_allele_frequency",
  se_col = "standard_error",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
dat_har <- harmonise_data(IBS_iv,GERD_outcome_data)
#write.csv(dat_har,file = "harmonise_finneIBSonGERD.csv")
#read.csv('harmonise_valIBSonGERD去除离群值.csv',sep = ',')
mr(dat_har)
res_or<-generate_odds_ratios(mr_res=mr(dat_har))
res_or
run_mr_presso(dat_har,NbDistribution = 3000)
mr_pleiotropy_test(dat_har)
mr_heterogeneity(dat_har)
mr_scatter_plot(mr_results = mr(dat_har,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median")),dat_har)
mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(dat_har))
mr_funnel_plot(singlesnp_results = mr_singlesnp(dat_har))
################################################
#validation IBS
IBS_dat <- as.data.frame(fread("IBSGCST90016564_buildGRCh37.tsv", header = T)) #读取LDL文件
head(IBS_dat)
IBS_dat$`p_value` <- as.numeric(IBS_dat$`p_value`)#将p值转为数值型变量
IBS_dat <- IBS_dat[which(IBS_dat$`p_value` < 1e-6),] #提取显著SNP用于后续clump
IBS_gwas <- IBS_dat[,c("variant_id", "p_value")] #选取rsid和p值这两列
colnames(IBS_gwas) <- c("rsid", "pval") #修改列名，列名必须为rsid和pval
head(IBS_gwas)

a <- ld_clump_local( dat = IBS_gwas, clump_kb = 10000, clump_r2 = 0.001, clump_p = 1, 
                     bfile = "I:/data_maf0.01_rs_ref/data_maf0.01_rs_ref", 
                     plink_bin = "I:/plink/plink_win64_20231211/plink.exe")
#这里需要注意bfile只需填plink文件的前缀 data_maf0.01_rs_ref即可
dim(a) #clump后只剩个22 IV了
head(a)
#[1] 802
IBS_iv <- IBS_dat[which(IBS_dat$variant_id%in%a$rsid), ] #返回源数据将clump后的IV信息提取出来
dim(IBS_iv) 
head(IBS_iv)
#[1] 80 10
IBS_iv<- format_data(
  dat=IBS_iv,
  type = "exposure",
  snps = IBS_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  se_col = "standard_error",
  eaf_col="effect_allele_frequency",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
#write.csv(IBS_iv,"valIBS_clumped.1e-6.csv")
GERD<-fread("GCST90000514_buildGRCh37GERD.tsv.gz")
head(GERD)
GERD <- data.frame(GERD)
GERD_outcome_data<- format_data(
  dat=GERD,
  type = "outcome",
  snps = IBS_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  eaf_col="effect_allele_frequency",
  se_col = "standard_error",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
dat_har <- harmonise_data(IBS_iv,GERD_outcome_data)
#write.csv(dat_har,file = "harmonise_valIBSonGERD.csv")
mr(dat_har)
res_or<-generate_odds_ratios(mr_res=mr(dat_har))
res_or
run_mr_presso(dat_har,NbDistribution = 3000)
mr_pleiotropy_test(dat_har)
mr_heterogeneity(dat_har)
mr_scatter_plot(mr_results = mr(dat_har,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median")),dat_har)
mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(dat_har))
mr_funnel_plot(singlesnp_results = mr_singlesnp(dat_har))
