library(remotes)
library(TwoSampleMR)
library(ieugwasr) #加载ieugwasr包，若没有安装，需先安装
library(data.table) #加载data.table包，若没有安装，需先安装
setwd('I:\\GWAS数据\\GERDonIBS多变量')
GERD_dat <- as.data.frame(fread("GCST90000514_buildGRCh37GERD.tsv.gz", header = T)) #读取LDL文件
head(GERD_dat)
GERD_dat$`p_value` <- as.numeric(GERD_dat$`p_value`)#将p值转为数值型变量
GERD_dat <- GERD_dat[which(GERD_dat$`p_value` < 5e-8),] #提取显著SNP用于后续clump
GERD_gwas <- GERD_dat[,c("variant_id", "p_value")] #选取rsid和p值这两列
colnames(GERD_gwas) <- c("rsid", "pval") #修改列名，列名必须为rsid和pval
head(GERD_gwas)

a <- ld_clump_local( dat = GERD_gwas, clump_kb = 10000, clump_r2 = 0.001, clump_p = 1, 
                     bfile = "I:/data_maf0.01_rs_ref/data_maf0.01_rs_ref", 
                     plink_bin = "I:/plink/plink_win64_20231211/plink.exe")
#这里需要注意bfile只需填plink文件的前缀 data_maf0.01_rs_ref即可
dim(a) #clump后只剩80个IV了
head(a)
#[1] 802
GERD_iv <- GERD_dat[which(GERD_dat$variant_id%in%a$rsid), ] #返回源数据将clump后的IV信息提取出来
dim(GERD_iv) 
head(GERD_iv)
#[1] 80 10
GERD_iv<- format_data(
  dat=GERD_iv,
  type = "exposure",
  snps = GERD_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  se_col = "standard_error",
  eaf_col="effect_allele_frequency",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
#GERDon芬兰IBS
IBS<-fread("finngen_R10_K11_IBS.gz")
head(IBS)
IBS <- data.frame(IBS)
IBS_outcome_data<- format_data(
  dat=IBS,
  type = "outcome",
  snps = GERD_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "rsids",
  beta_col = "beta",
  se_col = "sebeta",
  effect_allele_col = "alt",
  other_allele_col = "ref",
  pval_col = "pval",
  chr_col = "#chrom",
  pos_col = "pos"
)
#write.csv(IBS_outcome_data,file = "FinneIBS_outcome_finne.csv")
dat_har <- harmonise_data(GERD_iv,IBS_outcome_data)
#write.csv(dat_har,file = "harmonise_finneIBS.GERDonIBS.csv")
mr(dat_har)
res_or<-generate_odds_ratios(mr_res=mr(dat_har))
res_or
run_mr_presso(dat_har,NbDistribution = 3000)
mr_pleiotropy_test(dat_har)
mr_heterogeneity(dat_har)
mr_scatter_plot(mr_results = mr(dat_har,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median")),dat_har)
mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(dat_har))
mr_funnel_plot(singlesnp_results = mr_singlesnp(dat_har))
#Validation IBS
IBS<-fread("IBSGCST90016564_buildGRCh37.tsv")
head(IBS)
IBS <- data.frame(IBS)
IBS_outcome_data<- format_data(
  dat=IBS,
  type = "outcome",
  snps = GERD_iv$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  eaf_col="effect_allele_frequency",
  se_col = "standard_error",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
#write.csv(IBS_outcome_data,file = "IBS_outcome.GERDonIBS.csv")
dat_har <- harmonise_data(GERD_iv,IBS_outcome_data)
#write.csv(dat_har,file = "harmonise_GERDonvalIBS.csv")
mr(dat_har)
res_or<-generate_odds_ratios(mr_res=mr(dat_har))
res_or
run_mr_presso(dat_har,NbDistribution = 3000)
mr_pleiotropy_test(dat_har)
mr_heterogeneity(dat_har)
mr_scatter_plot(mr_results = mr(dat_har,method_list = c("mr_ivw","mr_egger_regression","mr_weighted_median")),dat_har)
mr_leaveoneout_plot(leaveoneout_results = mr_leaveoneout(dat_har))
mr_funnel_plot(singlesnp_results = mr_singlesnp(dat_har))
