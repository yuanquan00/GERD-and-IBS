library(TwoSampleMR)
library(data.table)
setwd('I:\\GWAS数据\\GERDonIBS多变量')
GERD <-fread('GCST90000514_buildGRCh37GERD.tsv.gz')
#head(ra)##

GERD_exp <- format_data(
  dat=GERD,
  type = "exposure",
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "variant_id",
  beta_col = "beta",
  se_col = "standard_error",
  eaf_col="effect_allele_frequency",
  effect_allele_col = "effect_allele",
  other_allele_col = "other_allele",
  pval_col = "p_value",
  chr_col = "chromosome",
  pos_col = "base_pair_location"
)
GERD_dat <- GERD_exp[which(GERD_exp$pval.exposure < 5e-8), ]
GERD_iv <- clump_data(GERD_dat)
dim(GERD_iv)

BMI<-as.data.frame(vroom::vroom("BMI.Meta-analysis_Locke_et_al+UKBiobank_2018_UPDATED.txt.gz"))
head(BMI)
BMI_exp <- format_data(
  dat=BMI,
  type = "exposure",
  header = TRUE,
  phenotype_col = "smoking",
  snp_col = "SNP",
  beta_col = "BETA",
  se_col = "SE",
  eaf_col="Freq_Tested_Allele_in_HRS",
  effect_allele_col = "Tested_Allele",
  other_allele_col = "Other_Allele",
  pval_col = "P",
  chr_col = "CHR",
  pos_col = "POS"
)
BMI_dat <- BMI_exp[which(BMI_exp$pval.exposure < 5e-8), ]
BMI_iv <- clump_data(BMI_dat)
dim(BMI_iv)

head(GERD_iv)
snp1<-as.data.frame(cbind(GERD_iv$SNP,GERD_iv$pval.exposure))
head(snp1)

head(BMI_iv)
snp2<-as.data.frame(cbind(BMI_iv$SNP,BMI_iv$pval.exposure))
head(snp2)
snpall<-rbind(snp1,snp2)
dim(snpall)
colnames(snpall)<-c("SNP",'pval.exposure')
snpclump<-as.data.frame(unique(snpall$SNP))
dim(snpclump)
colnames(snpclump)<-'SNP'
snpfinal<-snpall[which(snpall$SNP%in%snpclump$SNP),]
snpaa<-clump_data(snpfinal)
dim(snpaa)

GERDsnp <- GERD_exp[which(GERD_exp$SNP%in%snpaa$SNP),]
head(GERDsnp)
GERDsnp$exposure<-"GERD"
BMIsnp <- BMI_exp[which(BMI_exp$SNP%in%snpaa$SNP),]
head(BMIsnp)
BMIsnp$exposure<-"BMI"


trait1<-GERDsnp[,c(1,2,3,4,5,6,7,8,9,10,11,12,13)]
trait2<-BMIsnp[,c(2,3,1,4,5,6,7,8,9,10,11,12,13)]
head(trait1)
head(trait2)
exposure_dat<-rbind(trait1,trait2)
dim(exposure_dat)
head(exposure_dat)

IBS <-fread('finngen_R10_K11_IBS.gz')
head(IBS)
IBS_out <- format_data(
  dat=IBS,
  type = "outcome",
  snps = exposure_dat$SNP,
  header = TRUE,
  phenotype_col = "phenotype",
  snp_col = "rsids",
  beta_col = "beta",
  se_col = "sebeta",
  eaf_col="af_alt",
  effect_allele_col = "alt",
  other_allele_col = "ref",
  pval_col = "pval",
  chr_col = "#chrom",
  pos_col = "pos"
)

head(IBS_out)
###############################
dim(IBS_out)
mvdat<-mv_harmonise_data(exposure_dat,IBS_out)
dim(mvdat)
#head(mvdat)
#View(mvdat)

res<-mv_multiple(mvdat,plots = F)
res
ava<-res$result
ava$or<-exp(ava$b)
ava$lci<-exp(ava$b - 1.96*ava$se)
ava$uci<-exp(ava$b + 1.96*ava$se)
ava

write.table(ava,"GERDonIBS矫正BMItwo包MR结果.xls",sep="\t")
#############################整理mvdat的格式

exposure_beta <- as.data.frame(mvdat$exposure_beta)
exposure_se <- as.data.frame(mvdat$exposure_se)
outcome_beta <- as.data.frame(mvdat$outcome_beta)
outcome_se <- as.data.frame(mvdat$outcome_se)
outcome_se$rsid <- rownames(exposure_beta)
mvmvdat <- as.data.frame(c(exposure_beta,exposure_se,outcome_beta,outcome_se))
head(mvmvdat)
colnames(mvmvdat) <- c("GERD_beta","BMI_beta","GERD_se","BMI_se","ipf_beta","ipf_se","SNP")
head(mvmvdat)
dim(mvmvdat)
newmvdat=mvmvdat
colnames(newmvdat) <- c("GERD_beta","BMI_beta","GERD_se","BMI_se","Migraine_beta","Migraine_se","SNP")
newmvdat
write.table(newmvdat,"GERDonIBS矫正BMI的SNP信息.xls",sep="\t")
######################
library(MendelianRandomization)
MRMVInputObject_1<-mr_mvinput(
  bx=cbind(mvmvdat$GERD_beta,mvmvdat$BMI_beta),
  bxse=cbind(mvmvdat$GERD_se,mvmvdat$BMI_se),
  by = mvmvdat$ipf_beta, 
  byse = mvmvdat$ipf_se,
  snps = mvmvdat$SNP)
#MRMVInputObject_1
mr_mvivw <- mr_mvivw(MRMVInputObject_1, 
                     model = "default",
                     correl = FALSE,
                     distribution = "normal",
                     alpha = 0.05)

mr_mvivw

##############################
mr_mvegger <- mr_mvegger(MRMVInputObject_1,
                         orientate = 1,
                         correl = FALSE,
                         distribution = "normal",
                         alpha = 0.05)
mr_mvegger

mvrest_ivw <- cbind(mr_mvivw@Exposure,mr_mvivw@SNPs, mr_mvivw@Estimate, mr_mvivw@StdError, 
                    exp(mr_mvivw@Estimate), exp(mr_mvivw@CILower), exp(mr_mvivw@CIUpper), mr_mvivw@Pvalue)

mvrest_egger <- cbind(mr_mvegger@Exposure,mr_mvegger@SNPs, mr_mvegger@Estimate, mr_mvegger@StdError.Est, 
                      exp(mr_mvegger@Estimate), exp(mr_mvegger@CILower.Est), exp(mr_mvegger@CIUpper.Est), mr_mvegger@Pvalue.Est)

Egger_intercept<-cbind(mr_mvegger@Exposure, mr_mvegger@SNPs, mr_mvegger@Intercept, mr_mvegger@StdError.Int, exp(mr_mvegger@Intercept),
                       mr_mvegger@CILower.Int, mr_mvegger@CIUpper.Int, mr_mvegger@Pvalue.Int)

mymvrest<-as.data.frame(rbind(mvrest_ivw, mvrest_egger, Egger_intercept))
colnames(mymvrest)<-c("exposure","snps", "beta", "se", "or", "lci", "uci", "pval")
rownames(mymvrest)<-c("GERD_ivw","BMI_IVW", "GERD_egger", "BMI_egger", "intercept","intercept2")
mymvrest<-mymvrest[-6,]
mymvrest
write.table(mymvrest,'GERDonIBS矫正BMI的MR结果.csv',sep = ',')
yzx<-as.data.frame(mr_mvegger@Heter.Stat)
yzx
write.table(yzx,'GERDonIBS矫正BMI的异质性.csv',sep = ',')

####################超级无敌隔断
#vignette("MVMR")
library(MVMR)
head(rawdat_mvmr)
head(mvmvdat)
F.data <- format_mvmr(BXGs = mvmvdat[,c(1,2)],
                      BYG = mvmvdat[,5],
                      seBXGs = mvmvdat[,c(3,4)],
                      seBYG = mvmvdat[,6],
                      RSID = mvmvdat[,7])
head(F.data)
sres <- strength_mvmr(r_input = F.data, gencov = 0)
sres
mvmrcovmatrix<-matrix(c(1,-0.1,-0.05,-0.1,1,0.2,-0.05,0.2,1), nrow = 2, ncol = 2)
Xcovmat<-phenocov_mvmr(mvmrcovmatrix,F.data[,6:7])
sres2 <- strength_mvmr(r_input = F.data, gencov = Xcovmat)
sres2
write.table(sres,'GERDonIBS的矫正BMI的F值.csv',sep = ',')
