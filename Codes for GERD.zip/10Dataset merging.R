# 安装Bioconductor的包管理工具BiocManager并安装所需的包
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")  # 安装limma包

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("sva")  # 安装sva包

# 加载所需的R包
library(limma)  # 加载limma包，用于差异表达分析和数据标准化
library(sva)    # 加载sva包，用于批次效应校正

# 设置工作目录为包含多个GEO数据集的文件夹
setwd("H:\\我的教程\\MR+机器学习\\22多个GEO数据集合并") 

# 获取工作目录下以".txt"结尾的所有文件名
files = dir()  # 列出当前工作目录下的所有文件
files = grep("txt$", files, value = TRUE)  # 筛选出所有以.txt结尾的文件
geneList = list()  # 创建一个空列表，用于存储每个文件中的基因名

# 循环读取每个txt文件，并提取文件中的基因名
for (file in files) {
  if (file == "merge.preNorm.txt") { next }  # 跳过已有的合并文件
  if (file == "merge.normalize.txt") { next }  # 跳过已有的标准化合并文件
  rt = read.table(file, header = TRUE, sep = "\t", check.names = FALSE)  # 读取数据文件
  geneNames = as.vector(rt[, 1])  # 提取第一列作为基因名
  uniqGene = unique(geneNames)  # 获取唯一的基因名列表
  header = unlist(strsplit(file, "\\.|\\-"))  # 使用"."或"-"分割文件名
  geneList[[header[1]]] = uniqGene  # 将每个文件的基因名存入列表
}

# 找到所有文件中共同的基因名
interGenes = Reduce(intersect, geneList)  # 使用intersect函数找出所有文件中的共同基因名

# 创建一个空的数据框，用于存储合并后的数据
allTab = data.frame()
batchType = c()  # 创建一个空向量用于存储批次信息

# 循环读取每个文件，并将基因表达数据合并
for (i in 1:length(files)) {
  inputFile = files[i]
  if (file == "merge.preNorm.txt") { next }  # 跳过已有的合并文件
  if (file == "merge.normalize.txt") { next }  # 跳过已有的标准化合并文件
  header = unlist(strsplit(inputFile, "\\.|\\-"))  # 分割文件名
  
  # 读取每个文件的基因表达数据
  rt = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE)
  rt = as.matrix(rt)
  rownames(rt) = rt[, 1]  # 设置行名为基因名
  exp = rt[, 2:ncol(rt)]  # 提取基因表达值
  dimnames = list(rownames(exp), colnames(exp))  # 设置行列名
  data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)  # 转换为数值矩阵
  rt = avereps(data)  # 平均重复样本的基因表达值
  colnames(rt) = paste0(header[1], "_", colnames(rt))  # 给列名加上文件名前缀
  
  # 合并数据
  if (i == 1) {
    allTab = rt[interGenes, ]  # 如果是第一个文件，初始化allTab
  } else {
    allTab = cbind(allTab, rt[interGenes, ])  # 之后的文件进行列绑定
  }
  batchType = c(batchType, rep(i, ncol(rt)))  # 记录批次信息
}

# 将合并后的数据保存为文件
outTab = rbind(geneNames = colnames(allTab), allTab)  # 在合并后的数据上添加基因名行
write.table(outTab, file = "merge.preNorm.txt", sep = "\t", quote = FALSE, col.names = FALSE)  # 保存文件

# 使用ComBat函数进行批次效应校正
outTab = ComBat(allTab, batchType, par.prior = TRUE)  # 批次效应校正
outTab = rbind(geneNames = colnames(outTab), outTab)  # 再次添加基因名行
write.table(outTab, file = "merge.normalize.txt", sep = "\t", quote = FALSE, col.names = FALSE)  # 保存校正后的文件
