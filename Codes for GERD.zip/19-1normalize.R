# 如果未安装BiocManager包，可以通过以下命令进行安装
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
# 使用BiocManager安装limma包
#BiocManager::install("limma")

# 加载limma包，用于基因表达数据分析
library(limma)

# 指定输入文件名
expFile = "geneMatrix.txt"  # 基因表达数据文件
conFile = "sample1.txt"  # 对照组样本文件
treatFile = "sample2.txt"  # 实验组样本文件

# 设置当前工作目录
setwd("D:\\常用生信分析\\68.9种机器学习算法模型来筛选疾病诊断特征基因\\01数据处理")

# 读取基因表达数据文件，并进行处理
rt = read.table(expFile, header = T, sep = "\t", check.names = F)  # 读取表达矩阵文件
rt = as.matrix(rt)  # 转换为矩阵格式
rownames(rt) = rt[,1]  # 将第一列（基因ID）设置为行名
exp = rt[,2:ncol(rt)]  # 去除第一列基因名称，保留表达数据
dimnames = list(rownames(exp), colnames(exp))  # 设置行列名称
data = matrix(as.numeric(as.matrix(exp)), nrow = nrow(exp), dimnames = dimnames)  # 确保数据为数值型
data = avereps(data)  # 对重复基因取平均值

# 读取对照组样本文件，提取对照组样本的列名
s1 = read.table(conFile, header = F, sep = "\t", check.names = F)  # 读取对照组样本信息
sampleName1 = as.vector(s1[,1])  # 提取对照组样本名
conData = data[,sampleName1]  # 提取对照组样本的表达数据

# 读取实验组样本文件，提取实验组样本的列名
s2 = read.table(treatFile, header = F, sep = "\t", check.names = F)  # 读取实验组样本信息
sampleName2 = as.vector(s2[,1])  # 提取实验组样本名
treatData = data[,sampleName2]  # 提取实验组样本的表达数据

# 合并对照组和实验组的表达数据
rt = cbind(conData, treatData)

# 构建样本类型信息，将对照组和实验组的样本分别标记为 "Control" 和 "Treat"
conNum = ncol(conData)  # 对照组样本数量
treatNum = ncol(treatData)  # 实验组样本数量
Type = c(rep("Control", conNum), rep("Treat", treatNum))  # 创建样本类型标签
outData = rbind(id = paste0(colnames(rt), "_", Type), rt)  # 添加样本类型标签到表达矩阵

# 将结果保存到文件 normalize.txt 中
write.table(outData, file = "normalize.txt", sep = "\t", quote = F, col.names = F)
