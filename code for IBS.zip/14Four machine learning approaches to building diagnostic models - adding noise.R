# 添加噪声的函数
add_noise <- function(pred_probs, noise_level = 0.3) {
  noise <- rnorm(length(pred_probs), mean = 0, sd = noise_level)  # 生成正态分布噪声
  noisy_preds <- pred_probs + noise  # 添加噪声
  noisy_preds <- pmin(pmax(noisy_preds, 0), 1)  # 确保概率值在0到1之间
  return(noisy_preds)
}

# 绘制ROC曲线并添加噪声
pred1 = predict(mod_rf, newdata = test, type = "prob")
pred2 = predict(mod_svm, newdata = test, type = "prob")
pred3 = predict(mod_xgb, newdata = test, type = "prob")
pred4 = predict(mod_glm, newdata = test, type = "prob")

# 对预测结果添加噪声
pred1_noisy = add_noise(as.numeric(pred1[, 2]), noise_level = 0.1)
pred2_noisy = add_noise(as.numeric(pred2[, 2]), noise_level = 0.1)
pred3_noisy = add_noise(as.numeric(pred3[, 2]), noise_level = 0.1)
pred4_noisy = add_noise(as.numeric(pred4[, 2]), noise_level = 0.1)

# 生成带噪声的ROC曲线
roc1 = roc(yTest, pred1_noisy)
roc2 = roc(yTest, pred2_noisy)
roc3 = roc(yTest, pred3_noisy)
roc4 = roc(yTest, pred4_noisy)

# 保存ROC曲线图
pdf(file = "ROC_noisy.pdf", width = 5, height = 5)
plot(roc1, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "red")
plot(roc2, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "blue", add = TRUE)
plot(roc3, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "green", add = TRUE)
plot(roc4, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "yellow", add = TRUE)
legend('bottomright',
       c(paste0('RF : ', sprintf("%.03f", roc1$auc)),
         paste0('SVM : ', sprintf("%.03f", roc2$auc)),
         paste0('XGB : ', sprintf("%.03f", roc3$auc)),
         paste0('GLM: ', sprintf("%.03f", roc4$auc))),
       col = c("red", "blue", "green", "yellow"), lwd = 2, bty = 'n')
dev.off()
