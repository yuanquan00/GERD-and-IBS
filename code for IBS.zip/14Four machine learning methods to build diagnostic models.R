# 安装必要的包（如果尚未安装）
#install.packages("caret")
#install.packages("DALEX")
#install.packages("ggplot2")
#install.packages("randomForest")
#install.packages("kernlab")
#install.packages("pROC")
#install.packages("xgboost")

# 加载所需的R包
library(caret)      # 用于机器学习的训练控制和数据分割
library(DALEX)      # 用于模型解释的包
library(ggplot2)    # 用于绘图
library(randomForest) # 随机森林算法
library(kernlab)    # 支持向量机算法
library(xgboost)    # XGBoost 算法
library(pROC)       # 用于绘制和评估ROC曲线

# 设置随机种子以保证结果可重复
set.seed(123)

# 设置输入文件路径
inputFile = "merge.normalize.txt"  # 标准化的合并数据
geneFile = "gene.txt"  # 基因列表文件

# 设置工作目录
setwd("H:\\我的教程\\MR+机器学习\\30四种机器学习方法构建诊断模型")

# 读取基因表达数据文件
data = read.table(inputFile, header = TRUE, sep = "\t", check.names = FALSE, row.names = 1)

# 读取基因列表文件，并提取所需的基因表达数据
geneRT = read.table(geneFile, header = FALSE, sep = "\t", check.names = FALSE)
data = data[as.vector(geneRT[, 1]), ]  # 提取基因表达数据
row.names(data) = gsub("-", "_", row.names(data))  # 将行名中的 "-" 替换为 "_"

# 提取样本的组别信息
data = t(data)  # 转置数据，将样本作为行
group = gsub("(.*)\\_(.*)", "\\2", row.names(data))  # 提取组别标签
data = as.data.frame(data)  # 将数据转换为数据框
data$Type = group  # 将组别信息添加到数据中

# 数据集划分为训练集和测试集
inTrain <- createDataPartition(y = data$Type, p = 0.7, list = FALSE)  # 按70%划分训练集
train <- data[inTrain, ]  # 训练集
test <- data[-inTrain, ]  # 测试集

# 随机森林模型训练
control = trainControl(method = "repeatedcv", number = 5, savePredictions = TRUE)  # 设置5折交叉验证
mod_rf = train(Type ~ ., data = train, method = 'rf', trControl = control)  # 训练随机森林模型

# 支持向量机模型训练
mod_svm = train(Type ~ ., data = train, method = "svmRadial", prob.model = TRUE, trControl = control)  # 训练SVM模型

# XGBoost模型训练
mod_xgb = train(Type ~ ., data = train, method = "xgbDART", trControl = control)  # 训练XGBoost模型

# 广义线性模型（GLM）训练
mod_glm = train(Type ~ ., data = train, method = "glm", family = "binomial", trControl = control)  # 训练GLM模型

# 定义预测函数
p_fun = function(object, newdata) {
  predict(object, newdata = newdata, type = "prob")[, 2]
}
yTest = ifelse(test$Type == "Control", 0, 1)  # 将测试集的类型转换为0和1

# 随机森林模型的模型解释
explainer_rf = explain(mod_rf, label = "RF", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_rf = model_performance(explainer_rf)

# 支持向量机模型的模型解释
explainer_svm = explain(mod_svm, label = "SVM", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_svm = model_performance(explainer_svm)

# XGBoost模型的模型解释
explainer_xgb = explain(mod_xgb, label = "XGB", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_xgb = model_performance(explainer_xgb)

# GLM模型的模型解释
explainer_glm = explain(mod_glm, label = "GLM", data = test, y = yTest, predict_function = p_fun, verbose = FALSE)
mp_glm = model_performance(explainer_glm)

# 生成模型残差的累积分布图
pdf(file = "residual.pdf", width = 6, height = 6)
p1 <- plot(mp_rf, mp_svm, mp_xgb, mp_glm)
print(p1)
dev.off()

# 生成模型残差的箱线图
pdf(file = "boxplot.pdf", width = 6, height = 6)
p2 <- plot(mp_rf, mp_svm, mp_xgb, mp_glm, geom = "boxplot")
print(p2)
dev.off()

# 绘制ROC曲线
pred1 = predict(mod_rf, newdata = test, type = "prob")
pred2 = predict(mod_svm, newdata = test, type = "prob")
pred3 = predict(mod_xgb, newdata = test, type = "prob")
pred4 = predict(mod_glm, newdata = test, type = "prob")
roc1 = roc(yTest, as.numeric(pred1[, 2]))
roc2 = roc(yTest, as.numeric(pred2[, 2]))
roc3 = roc(yTest, as.numeric(pred3[, 2]))
roc4 = roc(yTest, as.numeric(pred4[, 2]))

pdf(file = "ROC.pdf", width = 5, height = 5)
plot(roc1, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "red")
plot(roc2, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "blue", add = TRUE)
plot(roc3, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "green", add = TRUE)
plot(roc4, print.auc = FALSE, legacy.axes = TRUE, main = "", col = "yellow", add = TRUE)
legend('bottomright',
       c(paste0('RF: ', sprintf("%.03f", roc1$auc)),
         paste0('SVM: ', sprintf("%.03f", roc2$auc)),
         paste0('XGB: ', sprintf("%.03f", roc3$auc)),
         paste0('GLM: ', sprintf("%.03f", roc4$auc))),
       col = c("red", "blue", "green", "yellow"), lwd = 2, bty = 'n')
dev.off()

# 提取重要特征并生成特征重要性图
importance_rf <- variable_importance(explainer_rf, loss_function = loss_root_mean_square)
importance_svm <- variable_importance(explainer_svm, loss_function = loss_root_mean_square)
importance_glm <- variable_importance(explainer_glm, loss_function = loss_root_mean_square)
importance_xgb <- variable_importance(explainer_xgb, loss_function = loss_root_mean_square)

# 绘制变量重要性图
pdf(file = "importance.pdf", width = 7, height = 10)
plot(importance_rf[c(1, (ncol(data) - 8):(ncol(data) + 1)), ],
     importance_svm[c(1, (ncol(data) - 8):(ncol(data) + 1)), ],
     importance_xgb[c(1, (ncol(data) - 8):(ncol(data) + 1)), ],
     importance_glm[c(1, (ncol(data) - 8):(ncol(data) + 1)), ])
dev.off()

# 将最重要的基因写入文件
geneNum = 5  # 提取前5个重要基因
write.table(importance_rf[(ncol(data) - geneNum + 2):(ncol(data) + 1), ], file = "importanceGene.RF.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_svm[(ncol(data) - geneNum + 2):(ncol(data) + 1), ], file = "importanceGene.SVM.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_xgb[(ncol(data) - geneNum + 2):(ncol(data) + 1), ], file = "importanceGene.XGB.txt", sep = "\t", quote = FALSE, row.names = FALSE)
write.table(importance_glm[(ncol(data) - geneNum + 2):(ncol(data) + 1), ], file = "importanceGene.GLM.txt", sep = "\t", quote = FALSE, row.names = FALSE)